CIS 2336 EXAM2-SECTION 2-PROGRAMMING QUESTION -60 POINTS

This repository contains files for the Exam 2 submission.

## Instructions:

1. **Clone this repository:** to visual studios

2. **Work on the code file in this repository:**
   
- You can create new files  as needed as per the instructions according to the exam requirements.

3. **Commit your changes:**

4. **Push changes back to the repository:**

5. **Verify your changes on GitHub:**
- After pushing your changes, visit your repository on GitHub to verify that your files have been updated.

6. **Submit your Exam 2:**
- Once you have completed your changes and pushed them to the repository, your Exam 2 submission to GitHub is complete.  Please also zip the files as per instructions and upload it to canvas.

