
# Status

* Home ✅

* Menu ✅

* Order ✅

* Partner ✅

* Owner ✅



# JavaScript Libraries used

* [jQuery version 3.7.1](https://jquery.com/)



# Credits to

## Assignment 1

* [Furinkan](https://discordapp.com/users/351737307293941770) [Discord: Furinkan] (Reviewed the first draft and introduced div-classes to better space elements)

* [René](https://discordapp.com/users/276642068892352513) [Discord: cunning_prophet] (Introduced Flexboxes to improve mobile viewing)

## Assignment 2

* [Andrew Pougher](https://jsfiddle.net/apougher/4ch51z2z/) (Made simple jQuery filter for checkboxes)

## Assignment 3
* [Furinkan](https://discordapp.com/users/351737307293941770) [Discord: Furinkan] (Helped me optimize my event callers)
* [MelkorNemesis](https://melkornemesis.medium.com/prevent-unwanted-characters-in-input-f2967132decb) (Made a regular expression filter)
